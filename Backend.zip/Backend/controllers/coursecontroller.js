
const asynchandler = require("express-async-handler");
const Courses = require("../models/coursemodel");
const Users = require("../models/usermodel");


const getallusercourses = asynchandler(async (req, res) => {
  // console.log(req.query.username)

  try {
    const currUser = await Users.findOne({ username: req.query.username });
    const coursejson = currUser["progressReports"]
    if(coursejson.length==0)
      res.status(200).json({ "message": "no courses" })
    else
    res.json(coursejson);
    console.log(coursejson.length.toString() + " courses found.");
  } catch (err) {
    console.error('Error fetching user courses:', err);
    res.status(500).json({ "message": "-1" });
  }
});



const getallcourses = asynchandler(async (req, res) => {
  try {
    const courses = await Courses.find({});
    res.json(courses);
  } catch (err) {
    console.error('Error fetching all courses:', err);
    res.status(500).json({ "message": "-1" });
  }
});


const seecourse = asynchandler(async (req, res) => {
  try {
    const course = await Courses.findById( req.query.courseid);
   
      res.json(course);
    
  } catch (err) {
    console.error('Error fetching specific course:', err);
    res.status(500).json({ "message": "-1" });
  }
});


const enrollincourse = asynchandler(async (req, res) => {

const username=req.body.username;
const courseid=req.body.courseid;
try {
  const updatedCourse = await Courses.findByIdAndUpdate(
    courseid, // Ensure this variable is correctly defined or received from request
    { $addToSet: { enrolled: username } }, // Using $addToSet to avoid duplicates
    { new: true } // Return the updated document
    
    
  );
  const updatedUser = await Users.findOneAndUpdate(
    { username: req.body.username }, // find document by username
    {
      $push: {
        progressReports: {
          courseId: req.body.courseId,
          title: req.body.title,
          currentProgress: 0, // New course, so progress is 0
          lastAccessed: new Date(), // Set to current date
        }
      }
    },
    { new: true } // Return the updated user document
);




  res.json({ message: "+1" });
} catch (err) {
  console.error('Error enrolling user:', err);
  res.status(500).json({ message: "-1" });
}
});

const addcourse = asynchandler(async (req, res) => {
  try {
    const { course_name, course_desc, course_instructor, course_cost, enrolled } = req.body;
    const course = new Courses({
      course_name,
      course_desc,
      course_instructor,
      course_cost,
      enrolled
    });
    const savedCourse = await course.save();
    res.status(201).json({message:"course successfully added"});
  } catch (error) {
    res.status(400).json({message:"-1"});
  }
});


module.exports = { getallcourses, getallusercourses, seecourse, enrollincourse, addcourse };
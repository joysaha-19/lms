const express = require("express");
const router = express.Router();
const {
  getallcourses,
  getallusercourses,
  seecourse,
  enrollincourse,
  addcourse
} = require("../controllers/coursecontroller");
const validatetoken = require("../middleware/accesstokenhandler2");
// Define your routes here, for example:
router.get("/allcourses", validatetoken, getallcourses);
router.get("/usercourses", validatetoken, getallusercourses);
router.post("/enroll", validatetoken, enrollincourse);
router.get("/seecourse",validatetoken,seecourse);
router.post("/addcourse", validatetoken, addcourse);
module.exports = router;